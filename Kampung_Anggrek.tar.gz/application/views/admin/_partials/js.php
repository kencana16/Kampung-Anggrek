<script src="<?php echo base_url()?>assets/js/jquery-3.4.1.min.js"></script>

<script src="<?php echo base_url()?>assets/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo base_url()?>assets/js/scripts.js"></script>



<script src="<?php echo base_url()?>assets/js/fontawesome.all.min.js"></script>

<script src="<?php echo base_url()?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>assets/js/dataTables.bootstrap4.min.js"></script>

<script src="<?php echo base_url()?>assets/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url()?>assets/js/buttons.flash.min.js"></script>
<script src="<?php echo base_url()?>assets/js/jszip.min.js"></script>
<script src="<?php echo base_url()?>assets/js/pdfmake.min.js"></script>
<script src="<?php echo base_url()?>assets/js/vfs_fonts.js"></script>
<script src="<?php echo base_url()?>assets/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url()?>assets/js/buttons.print.min.js"></script>



