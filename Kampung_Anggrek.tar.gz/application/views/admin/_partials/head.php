<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta name="description" content="" />
<meta name="author" content="" />
<title><?php echo SITE_NAME .": ". ucfirst($this->uri->segment(1)) ." - ". ucfirst($this->uri->segment(2)) ?></title>
<link href="<?php echo base_url()?>assets/css/styles-admin.css" rel="stylesheet" />
<link href="<?php echo base_url()?>assets/css/dataTables.bootstrap4.min.css" rel="stylesheet"/>
<link href="<?php echo base_url()?>assets/css/buttons.dataTables.min.css" rel="stylesheet"/>
<link href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css" rel="stylesheet"/>

