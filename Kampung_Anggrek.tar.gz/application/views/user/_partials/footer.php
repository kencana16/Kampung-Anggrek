<div class="bg-success text-white py-5">

    <div class="container row m-auto">

        <div class="col-md-7 row">

            <img class="col-4" src="<?= base_url('assets/images/Kampung%20Anggrek%20APK.png')?>" alt="">

            <div class="col-7">

                <h4>Kampung Anggrek Sekarang Sudah Tersedia Di Android</h4>

                <br><a href="https://drive.google.com/file/d/1MFvdxF4xOGwepr5wq2JcBAJXsT2-cHF6/view"  class="btn btn-lg btn-beli"> Download APP</a>

            </div>

        </div>

        <div class="col-md-5">

            <h3>Kampung Anggrek</h3>

            <i class="fas fa-map-marker-alt mr-4"></i>Purwosari, Kec. Mijen, Kota Semarang, Jawa Tengah 50217, Indonesia <br>

            <i class="fas fa-phone-alt mr-4"></i>+62 857-4222-3710 <br>

            <i class="fab fa-instagram mr-4"></i>KampungAnggrek <br>

            <i class="fab fa-facebook-f mr-4"></i>Kampung Anggrek <br>

        </div>

        <div class="col-12 text-center align-item-bottom mt-auto">

            <small>Copyright &copy; 2020 &bull; Kampung Anggrek</small><br>

        Riyan Surya Kencana - A22.2018.02684

        </div>

    </div>

</div>