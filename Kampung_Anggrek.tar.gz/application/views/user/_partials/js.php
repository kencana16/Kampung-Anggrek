<script src="<?php echo base_url()?>assets/js/jquery-3.4.1.min.js"></script>
<script src="<?php echo base_url()?>assets/js/jquery.formatCurrency-1.4.0.pack.js"></script>
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>

<!--<script src="<?php echo base_url()?>assets/js/fontawesome.all.min.js" ></script>-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
