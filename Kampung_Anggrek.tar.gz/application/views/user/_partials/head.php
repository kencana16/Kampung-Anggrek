<meta charset="utf-8" />

<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

<meta name="description" content="" />

<meta name="author" content="" />

<title><?php echo SITE_NAME." ".ucfirst($this->uri->segment(2)) ?></title>

<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css" />

<link rel="stylesheet" href="<?php echo base_url()?>assets/css/styles-user.css" />

<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet">

<link href="<?php echo base_url()?>assets/css/dataTables.bootstrap4.min.css" rel="stylesheet"/>

